<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_DELETED' => 'Deleted',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Name',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_NAME' => 'Name',
  'LBL_REMOVE' => 'Remove',
  'LBL_LIST_FORM_TITLE' => 'User Preferences Mass Update List',
  'LBL_MODULE_NAME' => 'User Preferences Mass Update',
  'LBL_MODULE_TITLE' => 'User Preferences Mass Update',
  'LBL_HOMEPAGE_TITLE' => 'My User Preferences Mass Update',
  'LNK_NEW_RECORD' => 'Create User Preferences Mass Update',
  'LNK_LIST' => 'View User Preferences Mass Update',
  'LNK_IMPORT_UP_USERPREFERENCES' => 'Import User Preferences Mass Update',
  'LBL_SEARCH_FORM_TITLE' => 'Search User Preferences Mass Update',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_UP_USERPREFERENCES_SUBPANEL_TITLE' => 'User Preferences Mass Update',
  'LBL_NEW_FORM_TITLE' => 'New User Preferences Mass Update',
  'LBL_DATE_FORMAT' => 'Date Format',
  'LBL_DATE_FORMAT_ENABLE' => 'Date Format Enable',
  'LBL_TIME_FORMAT' => 'Time Format',
  'LBL_TIME_FORMAT_ENABLE' => 'Time Format Enable',
  'LBL_TIMEZONE' => 'Timezone',
  'LBL_TIMEZONE_ENABLE' => 'Timezone Enable',
  'LBL_FIRST_DAY_WEEK' => 'first day week',
  'LBL_FIRST_DAY_OF_THE_WEEK_ENABLE' => 'First Day of the Week Enable',
  'LBL_CURRENCY' => 'Currency',
  'LBL_CURRENCT_ENABLE' => 'Currenct Enable',
  'LBL_CURRENCY_SIGNIFICANT_DIGITS' => 'Currency Significant Digits',
  'LBL_CURRENCY_SIGNIFICANT_DIGIT_ENA' => 'Currency Significant Digit Ena',
  'LBL_DECIMAL_SYMBOL' => 'Decimal Symbol',
  'LBL_DECIMAL_SYMBOL_ENABLE' => 'Decimal Symbol Enable',
  'LBL_THOUSANDS_SEPARATOR' => '1000s Separator',
  'LBL_THOUSANDS_SEPARATOR_ENABLE' => '1000s Separator Enable',
  'LBL_EMAIL_CLIENT' => 'Email Client',
  'LBL_THEMES' => 'Themes',
  'LBL_EMAIL_CLIENT_ENABLE' => 'Email Client Enable',
  'LBL_THEMES_ENABLE' => 'Themes Enable',
  'LBL_LAYOUT_OPTIONS' => 'Layout Options',
  'LBL_LAYOUT_OPTIONS_ENABLE' => 'Layout Options Enable',
  'LBL_CURRENCY_ENABLE' => 'Currency Enable',
);