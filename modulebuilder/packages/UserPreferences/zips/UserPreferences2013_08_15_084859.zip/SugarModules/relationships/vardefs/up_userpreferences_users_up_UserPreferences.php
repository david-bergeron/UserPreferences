<?php
// created: 2013-08-15 08:48:59
$dictionary["up_UserPreferences"]["fields"]["up_userpreferences_users"] = array (
  'name' => 'up_userpreferences_users',
  'type' => 'link',
  'relationship' => 'up_userpreferences_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_UP_USERPREFERENCES_USERS_FROM_UP_USERPREFERENCES_TITLE',
  'id_name' => 'up_userpreferences_usersup_userpreferences_ida',
  'link-type' => 'many',
  'side' => 'left',
);
