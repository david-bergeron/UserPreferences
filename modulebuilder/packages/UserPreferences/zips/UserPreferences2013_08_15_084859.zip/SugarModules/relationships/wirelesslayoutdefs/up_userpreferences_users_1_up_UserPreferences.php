<?php
 // created: 2013-08-15 08:48:59
$layout_defs["up_UserPreferences"]["subpanel_setup"]['up_userpreferences_users_1'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_UP_USERPREFERENCES_USERS_1_FROM_USERS_TITLE',
  'get_subpanel_data' => 'up_userpreferences_users_1',
);
